export const links = [
  {
    label: 'GoPay wallet app',
    href: '#',
  },
  {
    label: 'GoPay cashout',
    href: '#',
  },
  {
    label: 'GoPay debit card',
    href: '#',
  },
  {
    label: 'College savings',
    href: '#',
  },
  {
    label: 'Auto save plan',
    href: '#',
  },
  {
    label: '401k retirement savings',
    href: '#',
  },
]
