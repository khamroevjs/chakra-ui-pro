import * as React from 'react'

export const StepContext = React.createContext(null)
