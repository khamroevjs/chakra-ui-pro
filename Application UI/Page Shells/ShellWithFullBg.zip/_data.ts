export const data = {
  users: [
    {
      name: 'Melinda Jones',
      image:
        'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixid=MXwxMjA3fDB8MHxzZWFyY2h8M3x8aGVhZHNob3R8ZW58MHx8MHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Ram Prakash',
      image:
        'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixid=MXwxMjA3fDB8MHxzZWFyY2h8Mnx8aGVhZHNob3R8ZW58MHx8MHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Gernald Hawkins',
      image:
        'https://images.unsplash.com/photo-1534308143481-c55f00be8bd7?ixid=MXwxMjA3fDB8MHxzZWFyY2h8Mjd8fGhlYWRzaG90fGVufDB8fDB8&ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Jessie Munday',
      image:
        'https://images.unsplash.com/photo-1595875708571-854a3492c245?ixid=MXwxMjA3fDB8MHxzZWFyY2h8NTZ8fGhlYWRzaG90fGVufDB8fDB8&ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Diana Fisher 🏳️‍🌈',
      image:
        'https://images.unsplash.com/photo-1531078215167-91fcfe45b39e?ixid=MXwxMjA3fDB8MHxzZWFyY2h8NjF8fGhlYWRzaG90fGVufDB8fDB8&ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=60',
    },
  ],
}
