import { chakra } from '@chakra-ui/react'
import { motion } from 'framer-motion'

export const MotionListItem = motion(chakra.li)
